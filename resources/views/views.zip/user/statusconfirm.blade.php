<!DOCTYPE html>
<html>
<head>
	<title>E-Commerce</title>
</head>
<body style="display: flex; justify-content: center; align-items: center; height: 90vh; text-align: center;">
	<p>{{$msg}}<br>Silahkan login kembali. Klik <a href="{{ route('login') }}">disini</a></p>
</body>
</html>
