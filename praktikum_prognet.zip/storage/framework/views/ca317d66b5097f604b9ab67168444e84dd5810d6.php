

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Review</h1>
    </div>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger mt-3">
        <p>Gagal : </p>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(Session::has('sukses')): ?>
    <p class="alert alert-success mt-3" style="text-align: center;"><?php echo e(Session::get('sukses')); ?></p>
    <?php endif; ?>
    <?php if(Session::has('gagal')): ?>
    <p class="alert alert-danger mt-3" style="text-align: center;"><?php echo e(Session::get('gagal')); ?></p>
    <?php endif; ?>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-12">
                <h6>Nama Produk : <?php echo e($review[0]->product_name); ?></h6>
            </div>
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead style="text-align: center;">
                            <tr>
                                <th>No</th>
                                <th>Konten</th>
                                <th>Rating</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody style="text-align: center;">
                            <?php $bil=1; ?>
                            <?php $__currentLoopData = $review[0]->review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($bil++); ?></td>
                                <td><?php echo e($d->content); ?> </td>
                                <td><?php echo e($d->rate); ?></td>
                                <td><a onclick="return confirm('Yakin melanjutkan hapus review ? ')" href="<?php echo e(route('admin.hapus.review', ['id' => $d->id, 'idproduk' => $review[0]->id])); ?>" class="btn btn-danger"><i class="fas fa-trash"></i> Hapus</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </form>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\praktikum_prognet\resources\views/admin/listreview.blade.php ENDPATH**/ ?>