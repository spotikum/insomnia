<!DOCTYPE html>
<html>
<head>
	<title>E-Commerce</title>
</head>
<body style="display: flex; justify-content: center; align-items: center; height: 90vh; text-align: center;">
	<p><?php echo e($msg); ?><br>Silahkan login kembali. Klik <a href="<?php echo e(route('login')); ?>">disini</a></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\praktikum_prognet\resources\views/user/statusconfirm.blade.php ENDPATH**/ ?>