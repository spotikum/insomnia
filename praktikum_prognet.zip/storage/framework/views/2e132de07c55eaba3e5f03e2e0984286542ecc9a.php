

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Courier</h1>
    </div>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-12 pb-4">
                <button class="btn btn-success" data-toggle="modal" data-target="#tambahcou"><i class="fas fa-plus"></i>Tambah data</button>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger mt-3">
                    <p>Gagal : </p>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php if(Session::has('sukses')): ?>
                <p class="alert alert-success mt-3" style="text-align: center;"><?php echo e(Session::get('sukses')); ?></p>
                <?php endif; ?>
                <?php if(Session::has('gagal')): ?>
                <p class="alert alert-danger mt-3" style="text-align: center;"><?php echo e(Session::get('gagal')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 table-responsive">
                <table class="table table-striped" id="tabelcou">
                    <thead>
                        <tr style="text-align: center;">
                            <th>No</th>
                            <th>Kurir</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $bil=1; ?>
                        <?php $__currentLoopData = $cou; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="text-align: center;">
                            <td><?php echo e($bil++); ?></td>
                            <td><?php echo e($c->courier); ?></td>
                            <td>
                                <button class="btn btn-primary" onclick="ubahcou('<?php echo $c->id; ?>','<?php echo $c->courier; ?>')"><i class="fas fa-edit"></i> Ubah</button>
                                <a onclick="return confirm('Yakin melanjutkan hapus kurir <?php echo e($c->courier); ?>')" href="<?php echo e(route('hapus.courier', ['id' => $c->id])); ?>" class="btn btn-danger"><i class="fas fa-trash"></i> Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\praktikum_prognet\resources\views/admin/listcourier.blade.php ENDPATH**/ ?>