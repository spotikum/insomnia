

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Products</h1>
    </div>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-12 pb-4">
                <button class="btn btn-success" data-toggle="modal" data-target="#tambahproduct"><i class="fas fa-plus"></i> Tambah data</button>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger mt-3">
                    <p>Gagal : </p>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php if(Session::has('sukses')): ?>
                <p class="alert alert-success mt-3" style="text-align: center;"><?php echo e(Session::get('sukses')); ?></p>
                <?php endif; ?>
                <?php if(Session::has('gagal')): ?>
                <p class="alert alert-danger mt-3" style="text-align: center;"><?php echo e(Session::get('gagal')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 table-responsive">
                <table class="table table-striped" id="tabelproduk" style="width: 1500px">
                    <thead>
                        <tr style="text-align: center;">
                            <th>No</th>
                            <th>Nama produk</th>
                            <th>Harga</th>
                            <th>Deskripsi</th>
                            <th>Rating</th>
                            <th>Stock</th>
                            <th>Berat</th>
                            <th>Foto</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $bil=1; ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="text-align: center;">
                            <td><?php echo e($bil++); ?></td>
                            <td><?php echo e($p->product_name); ?></td>
                            <td><?php echo e($p->price); ?></td>
                            <td><?php echo e($p->description); ?></td>
                            <td><?php echo e($p->product_rate); ?></td>
                            <td><?php echo e($p->stock); ?></td>
                            <td><?php echo e($p->weight); ?></td>
                            <td><a href="./../storage/images/produk/<?php echo e($p->image_name); ?>" target="_blank" style="text-decoration: none; color: #111"><?php echo e($p->image_name); ?></a></td>
                            <td>
                                <a class="btn btn-primary mr-1" href="<?php echo e(route('ubah.product.page', ['id' => $p->id ])); ?>"><i class="fas fa-edit"></i> Ubah</button>
                                <a onclick="return confirm('Yakin melanjutkan hapus produk <?php echo e($p->product_name); ?>')" href="<?php echo e(route('hapus.product', ['id' => $p->id])); ?>" class="btn btn-danger"><i class="fas fa-trash"></i> Hapus</a>
                                <button class="btn btn-success" onclick="gambarProduk(<?php echo $p->id; ?>)"><i class="fas fa-arrow-up"></i> Upload</button>
                                <a href="<?php echo e(route('listdiskon', ['id' => $p->id])); ?>" class="btn btn-info pull-right"><i class="fas fa-dollar-sign"></i> Diskon</a>
                                <a href="<?php echo e(route('listreview', ['id' => $p->id])); ?>" class="btn btn-secondary pull-right"><i class="fas fa-list"></i> Review</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\praktikum_prognet\resources\views/admin/listproducts.blade.php ENDPATH**/ ?>