

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Diskon</h1>
    </div>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger mt-3">
        <p>Gagal : </p>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(Session::has('sukses')): ?>
    <p class="alert alert-success mt-3" style="text-align: center;"><?php echo e(Session::get('sukses')); ?></p>
    <?php endif; ?>
    <?php if(Session::has('gagal')): ?>
    <p class="alert alert-danger mt-3" style="text-align: center;"><?php echo e(Session::get('gagal')); ?></p>
    <?php endif; ?>
    <div class="section-body">
        <form class="row" action="<?php echo e(route('savediskon')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="col-lg-12">
                <h6>Nama Produk : <?php echo e($diskon[0]->product_name); ?></h6>
            </div>
            <input type="hidden" name="idproduk" value="<?php echo e($diskon[0]->id); ?>">
            <div class="col-lg-4">
                <div class="form-group">
                    <label>Persentase</label>
                    <input type="number" class="form-control" name="persen" min="0" max="100" placeholder="Masukkan persentase diskon (%)" required>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="form-group">
                    <label>Tanggal Mulai</label>
                    <input type="date" class="form-control" name="start" required>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="form-group">
                    <label>Tanggal Berakhir</label>
                    <input type="date" class="form-control" name="end" required>
                </div>
            </div>
            <div class="col-lg-12 pb-4" style="text-align: center;">
                <button type="submit" class="btn btn-primary">Tambah</button>
            </div>
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead style="text-align: center;">
                            <tr>
                                <th>No</th>
                                <th>Persentase</th>
                                <th>Tanggal Mulai</th>
                                <th>Tanggal Berakhir</th>
                            </tr>
                        </thead>
                        <tbody style="text-align: center;">
                            <?php $bil=1; ?>
                            <?php $__currentLoopData = $diskon[0]->diskon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($bil++); ?></td>
                                <td><?php echo e($d->percentage); ?> % </td>
                                <td><?php echo e(date('d-m-Y', strtotime($d->start))); ?></td>
                                <td><?php echo e(date('d-m-Y', strtotime($d->end))); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </form>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\praktikum_prognet\resources\views/admin/listdiskon.blade.php ENDPATH**/ ?>