

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Products</h1>
    </div>
    <div class="section-body card" style="padding: 20px;">
        <div class="row">
            <div class="col-lg-12 pb-4">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger mt-3">
                    <p>Gagal : </p>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form class="row" action="<?php echo e(route('ubah.product')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($p->id); ?>">
            <div class="col-lg-6">
                <div class="form-group">
                    <label>Kategori</label>
                    <select class="form-control" name="kategori" required>
                        <option value="">--Select Here--</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c->id); ?>" <?php if($p->category_id == $c->id): ?><?php echo e('selected'); ?> <?php endif; ?>><?php echo e($c->category_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Produk</label>
                    <input type="text" value="<?php echo e($p->product_name); ?>" name="product_name" class="form-control" placeholder="Masukkan nama produk" required>
                </div>
                <div class="form-group">
                    <label>Harga</label>
                    <input type="number" min="0" name="harga" value="<?php echo e($p->price); ?>" class="form-control" placeholder="Masukkan harga produk" required>
                </div>
                <div class="form-group">
                    <label>Deskripsi</label>
                    <textarea name="deskripsi" class="form-control" placeholder="Masukkan deskripsi produk" required><?php echo e($p->description); ?></textarea>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>Rating produk</label>
                    <input type="number" min="1" max="5" value="<?php echo e($p->product_rate); ?>" name="rating" class="form-control" placeholder="Masukkan rating produk" required>
                </div>
                <div class="form-group">
                    <label>Stok</label>
                    <input type="number" min="0" name="stok" value="<?php echo e($p->stock); ?>" class="form-control" placeholder="Masukkan stok produk" required>
                </div>
                <div class="form-group">
                    <label>Berat</label>
                    <input type="number" min="0" name="berat" value="<?php echo e($p->weight); ?>" class="form-control" placeholder="Masukkan berat produk" required>
                </div>
                <div class="form-group pt-4" style="text-align: center;">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\praktikum_prognet\resources\views/admin/ubahproduct.blade.php ENDPATH**/ ?>