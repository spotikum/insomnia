<h3>Notifikasi Ecommerce Laravel</h3>
<p><?php echo e($msg); ?></p>
<p><?php echo e($email); ?> Klik <a href="<?php echo e($link); ?>">disini</a></p><?php /**PATH C:\xampp\htdocs\praktikum_prognet\resources\views/user/emailnotif.blade.php ENDPATH**/ ?>