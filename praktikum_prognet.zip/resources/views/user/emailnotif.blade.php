<h3>Notifikasi Ecommerce Laravel</h3>
<p>{{ $msg }}</p>
<p>{{ $email }} Klik <a href="{{$link}}">disini</a></p>