<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class UserController extends Controller
{
    function index(){
    	$data['produk'] = Product::all();
    	return view('user.homepage', $data);
    }

    function buyproduct(){
    	Product::findOrFail($_GET['id']);

    	$data = Product::where('id', $_GET['id'])->first();
    	echo "Produk dibeli : ".$data->product_name;
    }
}
